<?php 
include('Clases.php');
$PanelUsuario = new PanelUsuario();
$Opciones = new Opciones();
$Chat = new Chat();
$Online = new Online();
$Ficha = new Ficha();
$Feeling = new Feeling();
$Sala = new Sala();
$Herramientas = new Herramientas();
$Notificaciones = new Notificaciones();
$Visitas = new Visitas();
?>