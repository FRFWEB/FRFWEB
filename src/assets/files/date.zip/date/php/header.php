<header class="container panel-user">
	<div class="row text-center">
		<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1">
				<a href="panel_user.php" class="btn btn-block boder border-primary user_menu"><img src="../img/logo.png">
					<p>Inicio</p></a>
				</div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1">
				<a id="PerfilMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn btn-block boder border-primary user_menu"><img src="../img/perfil.png">
				<p>Perfiles</p></a>
  				<div class="dropdown-menu" aria-labelledby="PerfilMenuButton">
    				<a class="dropdown-item" href="perfiles_nuevos.php">Nuevos</a>
   					<a class="dropdown-item" href="perfiles_cerca.php">Cerca</a>
    				<a class="dropdown-item" href="perfiles_favoritos.php">Favoritos</a>
  				</div>
			</div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1">
				<a href="buscador.php" class="btn btn-block boder border-primary user_menu"><img src="../img/mundo.png">
				<p>Buscador</p></a>
			</div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1">
				<a href="#" class="user_menu btn btn-block boder border-primary user_menu"><img src="../img/visitas.png">
				<p>Visitas</p></a>
			</div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1">
				<a href="chat.php" class="user_menu btn btn-block boder border-primary user_menu"><img src="../img/chat.png">
				<p>Mensajes</p></a>
			</div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1">
				<a href="#" class="user_menu btn btn-block boder border-primary user_menu"><img src="../img/online.png">
				<p>Online</p></a>
			</div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1">
				<a href="#" class="user_menu btn btn-block boder border-primary user_menu"><img src="../img/feelings.png">
				<p>Feelings</p></a>
			</div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1">
				<a href="#" class="user_menu btn btn-block boder border-primary user_menu"><img src="../img/campana.png">
				<p>Cositas</p></a>
			</div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1">
				<a href="#" class="user_menu btn btn-block boder border-primary user_menu"><img src="../img/preferencias.png">
				<p>Prioridad</p></a>
			</div>
			<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1 dropdown">
				<button id="OpcionesMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn btn-block boder border-primary user_menu user_menu"><img src="../img/opciones.png">
				<p>Opciones</p></button>
  				<div class="dropdown-menu" aria-labelledby="OpcionesMenuButton">
    				<a class="dropdown-item" href="opciones_mificha.php">Mi ficha</a>
   					<a class="dropdown-item" href="#">Ajustes</a>
    				<a class="dropdown-item" href="logout.php">Salir</a>
  				</div>
			</div>
		<div class="col-1 col-sm-1 col-md-1 col-lg-1 col-xl-1"></div>
	</div>
</header>
<section class="container">
	<div class="row">
		<div class="col-12 text-center border border-primary btn">
			<h6 class="text text-primary">www.dateadventista.com</h6>
		</div>
	</div>
</section>