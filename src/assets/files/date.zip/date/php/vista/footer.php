<footer class="container-fluid footer">
	<div class="row">
		<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 text-center">
			<h2 style="color:#FFF;">Llegamos a todas partes del mundo</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center">
			<h5>América</h5>
			<img src="../img/c_americano.png" width="120">
		</div>
		<div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center">
			<h5>Asía</h5>
			<img src="../img/c_asiatico.png" width="120">
		</div>
		<div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center">
			<h5>África</h5>
			<img src="../img/c_africano.png" width="120">
		</div>
	</div>
	<div class="row">
		<div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2"></div>
		<div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center">
			<h5>Oceanía</h5>
			<img src="../img/c_oceanico.png" width="120">
		</div>
		<div class="col-4 col-sm-4 col-md-4 col-lg-4 col-xl-4 text-center">
			<h5>Europa</h5>
			<img src="../img/c_europeo.png" width="120">
		</div>
		<div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2"></div>
	</div>
	<div class="row">
		<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 footer-desing">
			
		</div>
	</div>
</footer>
<script type="text/javascript" src="../js/jquery3-4-1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script type="text/javascript" src="../js/efects.js"></script>
<script type="text/javascript" src="../js/functions.js"></script>