<head>
	<title>Date Adventista - Demo</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<!--<script type="text/javascript" src="../js/browserDetect.js"></script>
	<script type="text/javascript">
	if (BrowserDetect.browser == "Firefox") { 
    document.write("<LINK REL='stylesheet' HREF='../css/style_firefox.css' TYPE='text/css'>");
   	} else{
    document.write("<LINK REL='stylesheet' HREF='../css/style_chrome.css' TYPE='text/css'>");
    }
	</script>-->
	<link rel="stylesheet" type="text/css" href="../css/progress.css">
	<link rel="shortcut icon" href="../img/favicon.ico" type="image/x-icon">
	<link rel="icon" href="../img/favicon.ico" type="image/x-icon">
	<script src="../js/jquery3-4-1.min.js"></script>
	<script type="text/javascript" src="../js/googletranslate.js"></script>
	<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
	<script type="text/javascript" src="../js/ajax.js"></script>
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
</head>