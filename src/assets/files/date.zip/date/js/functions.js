function scrollDown(){
var objDiv = document.getElementById("chat");
objDiv.scrollTop = objDiv.scrollHeight;
}